// module.h
#ifndef MODULE_H
#define MODULE_H

void tampilkanSuhu(float suhu);

#endif