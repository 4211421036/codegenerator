// module.cpp
#include "module.h"
#include <Wire.h>
#include <Adafruit_SSD1306.h>

// Inisialisasi fungsi
void tampilkanSuhu(float suhu) {
  // logika tampilkan suhu di OLED
}